Everyone is welcome to submit any errors that occur with this script.
This whole script is coded by guldkage (me).
